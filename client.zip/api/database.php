<?php 
$conn = mysqli_connect ("localhost", "root", "", "minitgo") or die ("Database Not Connected!");
?>